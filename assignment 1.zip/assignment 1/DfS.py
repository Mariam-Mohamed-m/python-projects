from inspect import stack


def bfs(graph, start, goal):
    visited = []
    stack = [[start]]

    while stack:
        path = stack.pop(0)
        node = path[-1]

        if node in visited:
            continue

        visited.append(node)

        if node == goal:
            return path
        else:
            adjacent_nodes = graph.get(node, [])
            for node2 in adjacent_nodes:
                new_path = path.copy()
                new_path.append(node2)
                stack.append(new_path)


graph = {
    'S': ['A', 'B', 'C'],
    'A': ['D', 'E'],
    'B': ['F'],
    'C': ['G'],
    'D': [],
    'E': ['G'],
    'F': [],
    'G': []
}

solu = bfs(graph, 'S', 'G')
print("Solution is", solu)